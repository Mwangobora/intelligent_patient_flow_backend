from django.apps import AppConfig


class QueueingConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.queueing"
    label = "queueing"
